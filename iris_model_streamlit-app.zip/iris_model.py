import streamlit as st
import numpy as np
import joblib

model = joblib.load("iris_model.pkl")
species = ['setosa', 'versicolor', 'virginica']

st.title("Iris Flower Species Predictor")

# Sliders for input
sepal_len = st.slider("Sepal Length", 4.0, 8.0, 5.1)
sepal_wid = st.slider("Sepal Width", 2.0, 4.5, 3.5)
petal_len = st.slider("Petal Length", 1.0, 7.0, 1.4)
petal_wid = st.slider("Petal Width", 0.1, 2.5, 0.2)

input_data = np.array([[sepal_len, sepal_wid, petal_len, petal_wid]])

if st.button("Predict"):
    prediction = model.predict(input_data)
    st.success(f"Predicted Species: {species[prediction[0]]}")
